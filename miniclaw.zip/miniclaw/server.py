#!/usr/bin/env python3
"""
MiniClaw Web UI — browser-based chat interface
Run: python server.py
Then open: http://localhost:8080
"""

import json
import threading
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

BASE_DIR = Path(__file__).parent

def load_config():
    with open(BASE_DIR / "miniclaw.json") as f:
        return json.load(f)

CFG = load_config()

# Import agent (lazy to avoid import issues at startup)
_agent = None
def get_agent():
    global _agent
    if _agent is None:
        from agent import MiniClawAgent
        _agent = MiniClawAgent()
    return _agent


HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MiniClaw</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Syne:wght@400;700;800&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: #0d0f14;
    --surface: #13161e;
    --border: #1f2433;
    --accent: #e84040;
    --accent2: #ff7043;
    --text: #e8eaf0;
    --muted: #6b7080;
    --user-bg: #1a1f2e;
    --bot-bg: #111318;
    --mono: 'JetBrains Mono', monospace;
    --sans: 'Syne', sans-serif;
  }

  html, body { height: 100%; background: var(--bg); color: var(--text); font-family: var(--sans); }

  /* Layout */
  .app { display: flex; flex-direction: column; height: 100vh; max-width: 860px; margin: 0 auto; }

  /* Header */
  header {
    display: flex; align-items: center; gap: 12px;
    padding: 18px 24px;
    border-bottom: 1px solid var(--border);
    background: var(--surface);
  }
  .crab { font-size: 26px; animation: pulse 3s ease-in-out infinite; }
  @keyframes pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.12)} }
  .brand { font-size: 20px; font-weight: 800; letter-spacing: -0.5px; }
  .brand span { color: var(--accent); }
  .status-dot {
    width: 8px; height: 8px; border-radius: 50%;
    background: #2ecc71; margin-left: auto;
    box-shadow: 0 0 6px #2ecc71;
    animation: blink 2s ease-in-out infinite;
  }
  .status-dot.offline { background: #e84040; box-shadow: 0 0 6px #e84040; animation: none; }
  @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.3} }
  .model-tag {
    font-family: var(--mono); font-size: 11px; color: var(--muted);
    background: var(--border); padding: 3px 8px; border-radius: 4px;
  }

  /* Messages */
  .messages {
    flex: 1; overflow-y: auto; padding: 24px;
    display: flex; flex-direction: column; gap: 16px;
    scrollbar-width: thin; scrollbar-color: var(--border) transparent;
  }
  .msg { display: flex; gap: 12px; max-width: 100%; animation: fadeUp 0.2s ease; }
  @keyframes fadeUp { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:none} }
  .msg.user { flex-direction: row-reverse; }
  .avatar {
    width: 34px; height: 34px; border-radius: 8px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    font-size: 16px; font-weight: 700;
  }
  .msg.bot .avatar { background: var(--accent); color: white; }
  .msg.user .avatar { background: var(--border); color: var(--muted); font-size: 13px; }
  .bubble {
    padding: 12px 16px; border-radius: 12px; font-size: 14px; line-height: 1.6;
    max-width: calc(100% - 50px); white-space: pre-wrap; word-break: break-word;
  }
  .msg.bot .bubble { background: var(--bot-bg); border: 1px solid var(--border); border-top-left-radius: 2px; }
  .msg.user .bubble { background: var(--user-bg); border: 1px solid var(--border); border-top-right-radius: 2px; }
  .meta { font-family: var(--mono); font-size: 10px; color: var(--muted); margin-top: 4px; }
  .msg.user .meta { text-align: right; }

  /* Typing indicator */
  .typing .bubble { padding: 14px 20px; }
  .dots { display: flex; gap: 5px; }
  .dots span {
    width: 7px; height: 7px; border-radius: 50%;
    background: var(--muted); animation: dot 1.2s ease-in-out infinite;
  }
  .dots span:nth-child(2) { animation-delay: 0.2s; }
  .dots span:nth-child(3) { animation-delay: 0.4s; }
  @keyframes dot { 0%,80%,100%{transform:scale(0.7);opacity:0.5} 40%{transform:scale(1);opacity:1} }

  /* Input */
  .input-area {
    padding: 16px 24px;
    background: var(--surface);
    border-top: 1px solid var(--border);
    display: flex; gap: 10px; align-items: flex-end;
  }
  textarea {
    flex: 1; background: var(--bg); border: 1px solid var(--border);
    border-radius: 10px; padding: 12px 14px;
    color: var(--text); font-family: var(--sans); font-size: 14px;
    resize: none; outline: none; max-height: 120px; min-height: 48px;
    transition: border-color 0.2s;
    scrollbar-width: thin;
  }
  textarea:focus { border-color: var(--accent); }
  textarea::placeholder { color: var(--muted); }
  button.send {
    width: 48px; height: 48px; border-radius: 10px; border: none;
    background: var(--accent); color: white; cursor: pointer;
    font-size: 20px; display: flex; align-items: center; justify-content: center;
    transition: background 0.15s, transform 0.1s; flex-shrink: 0;
  }
  button.send:hover { background: var(--accent2); }
  button.send:active { transform: scale(0.93); }
  button.send:disabled { background: var(--border); cursor: not-allowed; }

  /* Quick commands */
  .quick-cmds {
    display: flex; gap: 8px; padding: 0 24px 12px; flex-wrap: wrap;
  }
  .cmd-btn {
    font-family: var(--mono); font-size: 11px;
    background: var(--border); border: none; color: var(--muted);
    padding: 4px 10px; border-radius: 5px; cursor: pointer;
    transition: color 0.15s, background 0.15s;
  }
  .cmd-btn:hover { background: var(--user-bg); color: var(--text); }

  /* Welcome */
  .welcome {
    text-align: center; padding: 48px 24px; color: var(--muted);
  }
  .welcome .big { font-size: 48px; margin-bottom: 16px; }
  .welcome h2 { font-size: 22px; font-weight: 800; color: var(--text); margin-bottom: 8px; }
  .welcome p { font-size: 14px; line-height: 1.7; max-width: 400px; margin: 0 auto; }

  /* Code blocks */
  .bubble code {
    font-family: var(--mono); background: var(--border);
    padding: 1px 5px; border-radius: 3px; font-size: 12px;
  }
</style>
</head>
<body>
<div class="app">
  <header>
    <div class="crab">🦀</div>
    <div class="brand">Mini<span>Claw</span></div>
    <div class="model-tag" id="modelTag">qwen2.5:1.5b</div>
    <div class="status-dot" id="statusDot" title="Ollama status"></div>
  </header>

  <div class="messages" id="messages">
    <div class="welcome">
      <div class="big">🦀</div>
      <h2>MiniClaw is ready</h2>
      <p>Your local AI assistant powered by Ollama.<br>
      Type a message or use a quick command below.</p>
    </div>
  </div>

  <div class="quick-cmds">
    <button class="cmd-btn" onclick="sendCmd('/status')">/status</button>
    <button class="cmd-btn" onclick="sendCmd('/skills')">/skills</button>
    <button class="cmd-btn" onclick="sendCmd('/plugins')">/plugins</button>
    <button class="cmd-btn" onclick="sendCmd('/memory')">/memory</button>
    <button class="cmd-btn" onclick="sendCmd('/clear')">/clear</button>
    <button class="cmd-btn" onclick="sendCmd('/help')">/help</button>
  </div>

  <div class="input-area">
    <textarea id="input" placeholder="Message MiniClaw... (Enter to send, Shift+Enter for newline)"
              rows="1" autofocus></textarea>
    <button class="send" id="sendBtn" onclick="sendMessage()">➤</button>
  </div>
</div>

<script>
const messagesEl = document.getElementById('messages');
const inputEl = document.getElementById('input');
const sendBtn = document.getElementById('sendBtn');
let welcomeShown = true;

function ts() {
  return new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
}

function addMessage(role, text, elapsed) {
  if (welcomeShown) {
    messagesEl.innerHTML = '';
    welcomeShown = false;
  }
  const msg = document.createElement('div');
  msg.className = `msg ${role}`;
  const avatar = role === 'bot' ? '🦀' : 'YOU';
  const meta = elapsed ? `${ts()} · ${elapsed}s` : ts();
  msg.innerHTML = `
    <div class="avatar">${avatar}</div>
    <div>
      <div class="bubble">${escHtml(text)}</div>
      <div class="meta">${meta}</div>
    </div>`;
  messagesEl.appendChild(msg);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return msg;
}

function showTyping() {
  const msg = document.createElement('div');
  msg.className = 'msg bot typing';
  msg.id = 'typing';
  msg.innerHTML = `<div class="avatar">🦀</div><div class="bubble"><div class="dots"><span></span><span></span><span></span></div></div>`;
  messagesEl.appendChild(msg);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function removeTyping() {
  document.getElementById('typing')?.remove();
}

function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
          .replace(/`([^`]+)`/g, '<code>$1</code>');
}

async function sendMessage() {
  const text = inputEl.value.trim();
  if (!text) return;
  inputEl.value = '';
  inputEl.style.height = 'auto';
  sendBtn.disabled = true;
  addMessage('user', text);
  showTyping();
  const t0 = Date.now();
  try {
    const resp = await fetch('/chat', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({message: text})
    });
    const data = await resp.json();
    removeTyping();
    const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
    addMessage('bot', data.response || '[No response]', elapsed);
  } catch(e) {
    removeTyping();
    addMessage('bot', `Error: ${e.message}`);
  }
  sendBtn.disabled = false;
  inputEl.focus();
}

function sendCmd(cmd) {
  inputEl.value = cmd;
  sendMessage();
}

// Auto-resize textarea
inputEl.addEventListener('input', () => {
  inputEl.style.height = 'auto';
  inputEl.style.height = Math.min(inputEl.scrollHeight, 120) + 'px';
});

inputEl.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// Check Ollama status
async function checkStatus() {
  try {
    const r = await fetch('/status');
    const d = await r.json();
    const dot = document.getElementById('statusDot');
    dot.className = 'status-dot' + (d.ollama ? '' : ' offline');
    dot.title = d.ollama ? 'Ollama: online' : 'Ollama: offline';
  } catch {}
}
checkStatus();
setInterval(checkStatus, 10000);
</script>
</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # Suppress default HTTP logging

    def send_json(self, data: dict, code=200):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/" or path == "/index.html":
            body = HTML.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", len(body))
            self.end_headers()
            self.wfile.write(body)
        elif path == "/status":
            agent = get_agent()
            self.send_json({
                "ollama": agent.ollama.is_running(),
                "model": CFG["ollama"]["model"],
                "skills": len(agent.skills.skills),
                "plugins": len(agent.plugins.plugins),
            })
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/chat":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            try:
                data = json.loads(body)
                message = data.get("message", "").strip()
                if not message:
                    self.send_json({"response": ""})
                    return
                agent = get_agent()
                response = agent.respond(message)
                self.send_json({"response": response})
            except Exception as e:
                self.send_json({"response": f"[Server error]: {e}"}, 500)
        else:
            self.send_response(404)
            self.end_headers()


def run_server():
    port = CFG["gateway"]["web_ui_port"]
    host = CFG["gateway"]["host"]
    server = HTTPServer((host, port), Handler)
    print(f"\n🦀 MiniClaw Web UI → http://localhost:{port}")
    print("   Press Ctrl+C to stop\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 Server stopped.")


if __name__ == "__main__":
    run_server()
