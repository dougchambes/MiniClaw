---
name: weather
version: 1.0.0
description: Get current weather for any city using wttr.in (no API key needed)
triggers: weather, forecast, temperature, rain, sunny, cold, hot
author: MiniClaw
---

# Weather Skill

Fetches current weather using the free wttr.in service.

## Usage

Just ask:
- "What's the weather in London?"
- "Weather forecast for Paris"
- "Is it going to rain in Sydney?"

Or run directly:
```
/skill weather London
```

## Notes

- No API key required
- Uses wttr.in public service
- Works offline if wttr.in is unreachable (returns error)
