"""
Weather skill — uses wttr.in (free, no API key)
"""
import re
import urllib.request
import urllib.parse


def run(args: str, memory, cfg: dict) -> str:
    """Fetch weather for a city extracted from the user's message."""
    city = _extract_city(args)
    if not city:
        return "Please specify a city. Example: /skill weather London"
    return _fetch_weather(city)


def _extract_city(text: str) -> str:
    """Simple city extraction — takes the last word(s) after known keywords."""
    text = text.strip()
    for kw in ["weather in", "forecast for", "weather for", "weather", "forecast"]:
        if kw in text.lower():
            idx = text.lower().index(kw) + len(kw)
            city = text[idx:].strip().split("?")[0].strip()
            if city:
                return city
    # If called directly with city as args
    return text.strip() or "London"


def _fetch_weather(city: str) -> str:
    city_enc = urllib.parse.quote(city)
    url = f"https://wttr.in/{city_enc}?format=4"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "MiniClaw/1.0"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = resp.read().decode().strip()
            return f"🌤️ Weather for {city}:\n{data}"
    except Exception as e:
        return f"Could not fetch weather for '{city}': {e}"
