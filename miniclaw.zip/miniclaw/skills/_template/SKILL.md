---
name: my_skill
version: 1.0.0
description: Brief one-line description of what this skill does
triggers: keyword1, keyword2, phrase that triggers this
author: Your Name
---

# My Skill

What this skill does in plain English.

## Usage

```
/skill my_skill [arguments]
```

## Examples

```
/skill my_skill do something
/skill my_skill with args
```

## Notes

Any additional notes about API keys, requirements, limitations, etc.
