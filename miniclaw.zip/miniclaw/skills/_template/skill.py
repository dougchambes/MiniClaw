"""
Template skill — copy this folder and rename to create your own skill.

The `run` function is called when:
  - The user types /skill <name> <args>
  - OR the user's message contains one of the trigger words from SKILL.md

Args:
  args    : str  — the user's full message or /skill arguments
  memory  : Memory — access to agent memory (memory.add_fact(), memory.data)
  cfg     : dict — the full miniclaw.json config

Return:
  str  — the skill output (shown to user, and passed to LLM for context)
  None — if skill can't handle this input (LLM responds normally)
"""


def run(args: str, memory, cfg: dict):
    # Parse args
    args = args.strip()
    if not args:
        return "Usage: /skill my_skill <something>"

    # Do work
    result = f"You said: {args}"

    # Optional: store something in memory
    # memory.add_fact(f"User asked about: {args}")

    return result
