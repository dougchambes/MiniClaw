"""
Notes skill — save and recall personal notes
"""
import json
from pathlib import Path
from datetime import datetime

NOTES_PATH = Path(__file__).parent.parent.parent / "memory" / "notes.json"


def _load() -> list:
    NOTES_PATH.parent.mkdir(parents=True, exist_ok=True)
    if NOTES_PATH.exists():
        try:
            return json.loads(NOTES_PATH.read_text())
        except Exception:
            pass
    return []


def _save(notes: list):
    NOTES_PATH.write_text(json.dumps(notes, indent=2))


def run(args: str, memory, cfg: dict) -> str:
    args = args.strip()
    parts = args.split(None, 1)
    sub = parts[0].lower() if parts else "list"
    rest = parts[1].strip() if len(parts) > 1 else ""

    notes = _load()

    if sub == "save" and rest:
        entry = {"text": rest, "ts": datetime.now().isoformat()}
        notes.append(entry)
        _save(notes)
        return f"✅ Note saved: \"{rest}\""

    if sub == "list":
        if not notes:
            return "No notes saved yet."
        lines = [f"{i+1}. [{n['ts'][:10]}] {n['text']}" for i, n in enumerate(notes[-20:])]
        return "📝 Your notes:\n" + "\n".join(lines)

    if sub == "search" and rest:
        matches = [n for n in notes if rest.lower() in n["text"].lower()]
        if not matches:
            return f"No notes matching '{rest}'."
        lines = [f"• {n['text']}" for n in matches[:10]]
        return f"Found {len(matches)} note(s):\n" + "\n".join(lines)

    if sub == "clear":
        _save([])
        return "🗑️ All notes cleared."

    return (
        "Usage:\n"
        "  /skill notes save <text>    — save a note\n"
        "  /skill notes list           — list recent notes\n"
        "  /skill notes search <term>  — search notes\n"
        "  /skill notes clear          — delete all notes"
    )
