---
name: notes
version: 1.0.0
description: Save and retrieve personal notes locally
triggers: note, remember this, save this, write down, remind me
author: MiniClaw
---

# Notes Skill

Save and recall notes directly from MiniClaw.

## Usage

```
/skill notes save Buy milk and eggs
/skill notes list
/skill notes search milk
/skill notes clear
```

Notes are stored in `memory/notes.json`.
