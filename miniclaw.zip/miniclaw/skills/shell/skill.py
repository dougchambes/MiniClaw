"""
Shell skill — runs whitelisted safe commands only
"""
import subprocess
import shlex

ALLOWED = {
    "ls", "pwd", "df", "free", "ps", "uname", "uptime",
    "date", "whoami", "hostname", "cat", "echo", "which",
    "find", "du", "top", "lscpu", "lsmem",
}


def run(args: str, memory, cfg: dict) -> str:
    args = args.strip()
    if not args:
        return "Usage: /skill shell <command>  (e.g. /skill shell df -h)"

    try:
        parts = shlex.split(args)
    except ValueError as e:
        return f"Bad command syntax: {e}"

    base_cmd = parts[0].lower()
    if base_cmd not in ALLOWED:
        return (
            f"Command '{base_cmd}' is not in the allowed list.\n"
            f"Allowed: {', '.join(sorted(ALLOWED))}"
        )

    try:
        result = subprocess.run(
            parts,
            capture_output=True,
            text=True,
            timeout=10,
        )
        output = result.stdout or result.stderr or "(no output)"
        # Trim very long output
        lines = output.strip().splitlines()
        if len(lines) > 40:
            lines = lines[:40] + [f"... ({len(lines) - 40} more lines truncated)"]
        return "```\n" + "\n".join(lines) + "\n```"
    except subprocess.TimeoutExpired:
        return "Command timed out (10s limit)."
    except FileNotFoundError:
        return f"Command not found: {parts[0]}"
    except Exception as e:
        return f"Error running command: {e}"
