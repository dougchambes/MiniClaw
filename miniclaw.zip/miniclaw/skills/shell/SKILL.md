---
name: shell
version: 1.0.0
description: Run safe shell commands on the local machine (ls, ps, df, free, etc.)
triggers: run command, show files, list files, disk space, cpu usage, memory usage, free memory
author: MiniClaw
---

# Shell Skill

Runs a whitelisted set of safe shell commands on your local machine.

## Allowed Commands

- `ls` — list files
- `pwd` — current directory  
- `df` — disk usage
- `free` — memory usage
- `ps aux` — running processes
- `uname` — system info
- `uptime` — system uptime
- `date` — current date/time
- `whoami` — current user

## Usage

```
/skill shell df -h
/skill shell free -h
/skill shell ls ~
```

## Safety

Only whitelisted commands are allowed. No pipes, no sudo.
