"""
Template plugin — copy this folder and rename to create your own plugin.

Plugins add /slash commands to MiniClaw.

Each command is a plain function that takes a string (the args after the command)
and returns a string (shown to the user).

Register your commands in the COMMANDS dict at the bottom.
"""


def mycommand(args: str) -> str:
    """
    Called when user types: /mycommand [args]
    Returns a string shown directly to the user.
    """
    if not args.strip():
        return "Usage: /mycommand <something>"
    return f"mycommand received: {args}"


# Register all commands this plugin provides
COMMANDS = {
    "mycommand": mycommand,
}
