"""
Calculator plugin — safe math evaluation
/calc 2 + 2 * 10
"""
import ast
import operator

_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}


def _safe_eval(node):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.BinOp):
        op = _OPS.get(type(node.op))
        if not op:
            raise ValueError(f"Unsupported operator: {node.op}")
        return op(_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp):
        op = _OPS.get(type(node.op))
        if not op:
            raise ValueError(f"Unsupported operator: {node.op}")
        return op(_safe_eval(node.operand))
    raise ValueError(f"Unsupported expression type: {type(node)}")


def calc(args: str) -> str:
    expr = args.strip()
    if not expr:
        return "Usage: /calc <expression>  e.g. /calc 15 * 4 + 7"
    try:
        tree = ast.parse(expr, mode="eval")
        result = _safe_eval(tree.body)
        # Format nicely
        if isinstance(result, float) and result == int(result):
            result = int(result)
        return f"🧮 {expr} = **{result}**"
    except ZeroDivisionError:
        return "Error: Division by zero."
    except Exception as e:
        return f"Could not evaluate '{expr}': {e}"


COMMANDS = {
    "calc": calc,
}
