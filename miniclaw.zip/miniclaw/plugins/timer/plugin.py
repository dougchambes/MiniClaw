"""
Timer plugin — /timer 60  (starts background timer)
"""
import threading
import time
import sys


def timer(args: str) -> str:
    args = args.strip()
    if not args:
        return "Usage: /timer <seconds>  e.g. /timer 60"
    try:
        secs = int(args.split()[0])
        label = " ".join(args.split()[1:]) or "Timer"
    except ValueError:
        return f"Invalid number of seconds: '{args}'"

    if secs <= 0 or secs > 86400:
        return "Timer must be between 1 and 86400 seconds."

    def _ring():
        time.sleep(secs)
        print(f"\n\n⏰ TIMER DONE: {label} ({secs}s)\n")
        sys.stdout.flush()

    t = threading.Thread(target=_ring, daemon=True)
    t.start()

    mins = secs // 60
    rem = secs % 60
    human = f"{mins}m {rem}s" if mins else f"{secs}s"
    return f"⏱️ Timer set for **{human}** — '{label}'"


COMMANDS = {
    "timer": timer,
}
