#!/usr/bin/env bash
# MiniClaw Setup Script
# Installs Ollama (if needed) and pulls qwen2.5:1.5b
# Compatible with Ubuntu/Debian Linux (ThinkCentre M910q)

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo -e "${GREEN}🦀 MiniClaw Setup${NC}"
echo "=================================="
echo "Hardware: ThinkCentre M910q (i5 7th Gen / 16GB)"
echo ""

# Check Python
if ! command -v python3 &>/dev/null; then
  echo -e "${RED}Python 3 is required. Install with: sudo apt install python3${NC}"
  exit 1
fi

PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo -e "✅ Python ${PY_VER} found"

# Check/Install Ollama
if ! command -v ollama &>/dev/null; then
  echo -e "${YELLOW}Installing Ollama...${NC}"
  curl -fsSL https://ollama.com/install.sh | sh
else
  echo -e "✅ Ollama found: $(ollama --version 2>/dev/null || echo 'installed')"
fi

# Start Ollama if not running
if ! curl -s http://localhost:11434/api/tags &>/dev/null; then
  echo -e "${YELLOW}Starting Ollama service...${NC}"
  ollama serve &>/dev/null &
  sleep 3
fi

# Pull the model
echo ""
echo -e "${YELLOW}Pulling qwen2.5:1.5b model (~1GB, CPU-friendly)...${NC}"
ollama pull qwen2.5:1.5b

echo ""
echo -e "✅ Model ready"

# Create memory/logs dirs
mkdir -p memory logs
echo -e "✅ Directories created"

echo ""
echo -e "${GREEN}=================================="
echo -e "🦀 MiniClaw is ready to go!"
echo -e "==================================${NC}"
echo ""
echo "  CLI mode:    python3 agent.py"
echo "  Web UI:      python3 server.py   → http://localhost:8080"
echo ""
echo "  Commands:    /help /skills /plugins /status /memory /clear"
echo ""
