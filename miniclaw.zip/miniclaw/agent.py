#!/usr/bin/env python3
"""
MiniClaw - Lightweight local AI assistant powered by Ollama
Inspired by OpenClaw, optimised for low-power hardware (i5 7th Gen / 16GB RAM)
"""

import json
import os
import sys
import time
import logging
import importlib.util
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Optional
import urllib.request
import urllib.error

# ─── Config ────────────────────────────────────────────────────────────────────

BASE_DIR = Path(__file__).parent
CONFIG_PATH = BASE_DIR / "miniclaw.json"


def load_config() -> dict:
    if not CONFIG_PATH.exists():
        print(f"[ERROR] Config not found: {CONFIG_PATH}")
        sys.exit(1)
    with open(CONFIG_PATH) as f:
        return json.load(f)


CFG = load_config()

# ─── Logging ───────────────────────────────────────────────────────────────────

log_path = BASE_DIR / CFG["logging"]["path"]
log_path.parent.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=getattr(logging, CFG["logging"]["level"].upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(log_path),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("miniclaw")

# ─── Memory ────────────────────────────────────────────────────────────────────

class Memory:
    def __init__(self):
        self.path = BASE_DIR / CFG["memory"]["path"]
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data = self._load()

    def _load(self) -> dict:
        if self.path.exists():
            try:
                with open(self.path) as f:
                    return json.load(f)
            except Exception:
                pass
        return {"facts": [], "conversation": [], "skills_used": []}

    def save(self):
        with open(self.path, "w") as f:
            json.dump(self.data, f, indent=2)

    def add_fact(self, fact: str):
        self.data["facts"].append({"fact": fact, "ts": datetime.now().isoformat()})
        if len(self.data["facts"]) > CFG["memory"]["max_entries"]:
            self.data["facts"] = self.data["facts"][-CFG["memory"]["max_entries"]:]
        self.save()

    def get_facts_summary(self) -> str:
        if not self.data["facts"]:
            return ""
        recent = self.data["facts"][-10:]
        return "Known facts:\n" + "\n".join(f"- {f['fact']}" for f in recent)

    def add_message(self, role: str, content: str):
        self.data["conversation"].append({"role": role, "content": content, "ts": datetime.now().isoformat()})
        max_hist = CFG["performance"]["max_history_messages"]
        if len(self.data["conversation"]) > max_hist * 2:
            self.data["conversation"] = self.data["conversation"][-(max_hist * 2):]
        self.save()

    def get_history(self) -> list:
        return [{"role": m["role"], "content": m["content"]} for m in self.data["conversation"]]


# ─── Skills ────────────────────────────────────────────────────────────────────

class Skill:
    """A skill is a SKILL.md file + optional Python implementation."""
    def __init__(self, name: str, path: Path):
        self.name = name
        self.path = path
        self.description = ""
        self.trigger_words = []
        self.py_module = None
        self._load()

    def _load(self):
        md_path = self.path / "SKILL.md"
        if md_path.exists():
            content = md_path.read_text()
            for line in content.splitlines():
                if line.startswith("description:"):
                    self.description = line.split(":", 1)[1].strip()
                if line.startswith("triggers:"):
                    self.trigger_words = [t.strip() for t in line.split(":", 1)[1].split(",")]
        # Load Python implementation if exists
        py_path = self.path / "skill.py"
        if py_path.exists():
            spec = importlib.util.spec_from_file_location(f"skill_{self.name}", py_path)
            mod = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(mod)
                self.py_module = mod
            except Exception as e:
                log.warning(f"Could not load skill {self.name}: {e}")

    def run(self, args: str, memory: Memory) -> Optional[str]:
        if self.py_module and hasattr(self.py_module, "run"):
            try:
                return self.py_module.run(args, memory, CFG)
            except Exception as e:
                return f"[Skill {self.name} error]: {e}"
        return None

    def matches(self, text: str) -> bool:
        lower = text.lower()
        return any(t.lower() in lower for t in self.trigger_words) if self.trigger_words else False


class SkillManager:
    def __init__(self, memory: Memory):
        self.memory = memory
        self.skills: dict[str, Skill] = {}
        self._discover()

    def _discover(self):
        skills_dir = BASE_DIR / CFG["skills"]["path"]
        skills_dir.mkdir(parents=True, exist_ok=True)
        for d in skills_dir.iterdir():
            if d.is_dir() and (d / "SKILL.md").exists():
                self.skills[d.name] = Skill(d.name, d)
                log.info(f"Loaded skill: {d.name}")

    def find_skill(self, text: str) -> Optional[Skill]:
        for skill in self.skills.values():
            if skill.matches(text):
                return skill
        return None

    def list_skills(self) -> str:
        if not self.skills:
            return "No skills loaded."
        lines = [f"• **{name}**: {s.description}" for name, s in self.skills.items()]
        return "Available skills:\n" + "\n".join(lines)

    def run_skill(self, name: str, args: str) -> str:
        if name not in self.skills:
            return f"Skill '{name}' not found."
        return self.skills[name].run(args, self.memory) or f"Skill '{name}' ran (no output)."


# ─── Plugins ───────────────────────────────────────────────────────────────────

class Plugin:
    """A plugin extends MiniClaw with a callable Python module."""
    def __init__(self, name: str, path: Path):
        self.name = name
        self.path = path
        self.description = ""
        self.commands: dict[str, callable] = {}
        self._load()

    def _load(self):
        py_path = self.path / "plugin.py"
        meta_path = self.path / "plugin.json"
        if meta_path.exists():
            meta = json.loads(meta_path.read_text())
            self.description = meta.get("description", "")
        if py_path.exists():
            spec = importlib.util.spec_from_file_location(f"plugin_{self.name}", py_path)
            mod = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(mod)
                if hasattr(mod, "COMMANDS"):
                    self.commands = mod.COMMANDS
            except Exception as e:
                log.warning(f"Could not load plugin {self.name}: {e}")


class PluginManager:
    def __init__(self):
        self.plugins: dict[str, Plugin] = {}
        self._discover()

    def _discover(self):
        plugins_dir = BASE_DIR / CFG["plugins"]["path"]
        plugins_dir.mkdir(parents=True, exist_ok=True)
        for d in plugins_dir.iterdir():
            if d.is_dir() and (d / "plugin.py").exists():
                self.plugins[d.name] = Plugin(d.name, d)
                log.info(f"Loaded plugin: {d.name}")

    def handle_command(self, cmd: str, args: str) -> Optional[str]:
        for plugin in self.plugins.values():
            if cmd in plugin.commands:
                try:
                    return plugin.commands[cmd](args)
                except Exception as e:
                    return f"[Plugin error]: {e}"
        return None

    def list_plugins(self) -> str:
        if not self.plugins:
            return "No plugins loaded."
        cmds = []
        for name, p in self.plugins.items():
            for cmd in p.commands:
                cmds.append(f"• /{cmd} — {p.description}")
        return "Available plugin commands:\n" + "\n".join(cmds) if cmds else "No commands registered."


# ─── Ollama Client ─────────────────────────────────────────────────────────────

class OllamaClient:
    def __init__(self):
        self.host = CFG["ollama"]["host"]
        self.model = CFG["ollama"]["model"]
        self.timeout = CFG["ollama"]["timeout"]

    def is_running(self) -> bool:
        try:
            req = urllib.request.Request(f"{self.host}/api/tags")
            with urllib.request.urlopen(req, timeout=3):
                return True
        except Exception:
            return False

    def chat(self, messages: list, system: str = "") -> str:
        url = f"{self.host}/api/chat"
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": CFG["agent"]["temperature"],
                "num_predict": CFG["agent"]["max_tokens"],
                "num_ctx": CFG["agent"]["context_window"],
            },
        }
        if system:
            payload["system"] = system

        data = json.dumps(payload).encode()
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                result = json.loads(resp.read())
                return result.get("message", {}).get("content", "").strip()
        except urllib.error.URLError as e:
            return f"[Ollama error]: Cannot connect to {self.host}. Is Ollama running? ({e})"
        except Exception as e:
            return f"[Ollama error]: {e}"


# ─── Agent ─────────────────────────────────────────────────────────────────────

class MiniClawAgent:
    def __init__(self):
        self.cfg = CFG
        self.memory = Memory()
        self.skills = SkillManager(self.memory)
        self.plugins = PluginManager()
        self.ollama = OllamaClient()
        self.name = CFG["agent"]["name"]

    def _build_system_prompt(self) -> str:
        base = CFG["agent"]["persona"]
        facts = self.memory.get_facts_summary()
        skills_list = self.skills.list_skills()
        plugins_list = self.plugins.list_plugins()
        parts = [base]
        if facts:
            parts.append(f"\n{facts}")
        parts.append(f"\n{skills_list}")
        parts.append(f"\n{plugins_list}")
        parts.append("\nIf the user asks you to remember something, prefix your response with [REMEMBER: <fact>].")
        parts.append("If a skill is relevant, mention you are using it.")
        return "\n".join(parts)

    def _extract_memory(self, response: str) -> str:
        """Pull out [REMEMBER: ...] tags and store them."""
        import re
        pattern = r"\[REMEMBER:\s*(.+?)\]"
        matches = re.findall(pattern, response, re.IGNORECASE)
        for fact in matches:
            self.memory.add_fact(fact.strip())
            log.info(f"Stored memory: {fact.strip()}")
        clean = re.sub(pattern, "", response).strip()
        return clean

    def _handle_slash_command(self, text: str) -> Optional[str]:
        """Handle /command style inputs."""
        if not text.startswith("/"):
            return None
        parts = text[1:].split(None, 1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        if cmd == "skills":
            return self.skills.list_skills()
        if cmd == "plugins":
            return self.plugins.list_plugins()
        if cmd == "memory":
            return self.memory.get_facts_summary() or "No memories stored yet."
        if cmd == "clear":
            self.memory.data["conversation"] = []
            self.memory.save()
            return "Conversation history cleared."
        if cmd == "skill":
            sub = args.split(None, 1)
            if len(sub) >= 1:
                return self.skills.run_skill(sub[0], sub[1] if len(sub) > 1 else "")
        if cmd == "status":
            online = self.ollama.is_running()
            return (
                f"**{self.name} Status**\n"
                f"• Ollama: {'✅ running' if online else '❌ offline'}\n"
                f"• Model: {self.ollama.model}\n"
                f"• Skills loaded: {len(self.skills.skills)}\n"
                f"• Plugins loaded: {len(self.plugins.plugins)}\n"
                f"• Memory entries: {len(self.memory.data['facts'])}"
            )
        if cmd == "help":
            return (
                "**MiniClaw Commands**\n"
                "/status      — check system status\n"
                "/skills      — list available skills\n"
                "/plugins     — list available plugins\n"
                "/skill <name> [args] — run a skill directly\n"
                "/memory      — show stored facts\n"
                "/clear       — clear conversation history\n"
                "/help        — this message"
            )
        # Try plugins
        result = self.plugins.handle_command(cmd, args)
        if result:
            return result
        return f"Unknown command: /{cmd}. Type /help for help."

    def respond(self, user_input: str) -> str:
        user_input = user_input.strip()
        if not user_input:
            return ""

        # Slash commands bypass the LLM
        slash_result = self._handle_slash_command(user_input)
        if slash_result is not None:
            return slash_result

        # Check if a skill should auto-trigger
        skill = self.skills.find_skill(user_input)
        skill_result = None
        if skill:
            skill_result = skill.run(user_input, self.memory)
            log.info(f"Auto-triggered skill: {skill.name}")

        # Build LLM messages
        history = self.memory.get_history()[-CFG["performance"]["max_history_messages"]:]
        messages = history + [{"role": "user", "content": user_input}]
        if skill_result:
            messages[-1]["content"] += f"\n\n[Skill '{skill.name}' result]: {skill_result}"

        system = self._build_system_prompt()
        response = self.ollama.chat(messages, system=system)
        response = self._extract_memory(response)

        # Store exchange in memory
        self.memory.add_message("user", user_input)
        self.memory.add_message("assistant", response)

        return response


# ─── CLI Chat Loop ──────────────────────────────────────────────────────────────

def run_cli():
    agent = MiniClawAgent()

    print(f"\n🦀 {CFG['agent']['name']} — Local AI Assistant")
    print(f"   Model: {CFG['ollama']['model']} via Ollama")
    print("   Type /help for commands, Ctrl+C to exit\n")

    if not agent.ollama.is_running():
        print("⚠️  WARNING: Ollama is not running. Start it with: ollama serve")
        print("   Then pull the model: ollama pull qwen2.5:1.5b\n")

    while True:
        try:
            user_input = input("You: ").strip()
            if not user_input:
                continue
            t0 = time.time()
            reply = agent.respond(user_input)
            elapsed = time.time() - t0
            print(f"\n{CFG['agent']['name']}: {reply}")
            print(f"  ({elapsed:.1f}s)\n")
        except (KeyboardInterrupt, EOFError):
            print("\n\n👋 Goodbye!")
            break


if __name__ == "__main__":
    run_cli()
