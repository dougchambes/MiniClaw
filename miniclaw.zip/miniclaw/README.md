# 🦀 MiniClaw

**Lightweight local AI assistant — powered by Ollama + Qwen 2.5 1.5B**

Inspired by [OpenClaw](https://openclaw.ai), trimmed down for low-power hardware like the **Lenovo ThinkCentre M910q (i5 7th Gen / 16 GB RAM)**. No cloud. No API key. Pure local.

---

## Features

| Feature | Description |
|---|---|
| 🧠 Local LLM | Runs on Ollama — `qwen2.5:1.5b` (~1 GB, CPU-friendly) |
| 💬 Web UI | Clean browser chat at `http://localhost:8080` |
| 🖥️ CLI mode | Terminal chat loop |
| 🔧 Skills | Folder-based skills with SKILL.md + skill.py |
| 🔌 Plugins | `/slash` command plugins |
| 🧩 Memory | Persistent facts + conversation history in JSON |
| 📋 JSON config | `miniclaw.json` — close to OpenClaw's config format |

---

## Quick Start

### 1. Run setup (installs Ollama + pulls model)

```bash
chmod +x setup.sh
./setup.sh
```

### 2. Start the Web UI

```bash
python3 server.py
```

Open **http://localhost:8080** in your browser.

### 3. Or use the CLI

```bash
python3 agent.py
```

---

## Configuration — `miniclaw.json`

```json
{
  "agent": {
    "name": "MiniClaw",
    "model": "ollama/qwen2.5:1.5b",
    "temperature": 0.7,
    "max_tokens": 1024,
    "context_window": 4096
  },
  "ollama": {
    "host": "http://localhost:11434",
    "model": "qwen2.5:1.5b"
  },
  "memory": {
    "enabled": true,
    "path": "./memory/memory.json"
  },
  "skills": { "path": "./skills" },
  "plugins": { "path": "./plugins" },
  "gateway": {
    "port": 8765,
    "web_ui": true,
    "web_ui_port": 8080
  },
  "performance": {
    "low_memory_mode": true,
    "max_history_messages": 20
  }
}
```

### Swap models easily

Edit `ollama.model` in `miniclaw.json`. Any Ollama model works:

```json
"model": "qwen2.5:1.5b"     ← default (fastest, ~1GB)
"model": "qwen2.5:3b"       ← smarter, still CPU-ok (~2GB)
"model": "llama3.2:3b"      ← alternative
"model": "mistral:7b"        ← best quality, needs ~8GB RAM
```

---

## Built-in Commands

| Command | Description |
|---|---|
| `/status` | Ollama status, model, loaded skills & plugins |
| `/skills` | List all available skills |
| `/plugins` | List all plugin commands |
| `/skill <name> [args]` | Run a skill directly |
| `/memory` | Show stored facts |
| `/clear` | Clear conversation history |
| `/help` | Show all commands |
| `/calc <expr>` | Calculator plugin |
| `/timer <secs> [label]` | Background countdown timer |

---

## Included Skills

### 🌤️ Weather (`/skill weather <city>`)
Fetches current weather via wttr.in — no API key needed.
```
What's the weather in London?
/skill weather Sydney
```

### 🖥️ Shell (`/skill shell <command>`)
Runs whitelisted safe commands on your machine.
```
/skill shell df -h
/skill shell free -h
/skill shell uptime
```

### 📝 Notes (`/skill notes save|list|search|clear`)
Save and recall personal notes locally.
```
/skill notes save Check the logs tomorrow
/skill notes list
/skill notes search logs
```

---

## Creating Your Own Skill

1. Copy `skills/_template/` to `skills/my_skill/`
2. Edit `SKILL.md` — set name, description, triggers
3. Edit `skill.py` — implement the `run()` function
4. Restart MiniClaw — skills are auto-discovered

```
skills/
  my_skill/
    SKILL.md    ← metadata + trigger words
    skill.py    ← run(args, memory, cfg) -> str
```

### SKILL.md minimum

```markdown
---
name: my_skill
description: Does something useful
triggers: keyword, another phrase
---
```

### skill.py minimum

```python
def run(args: str, memory, cfg: dict) -> str:
    return f"Hello from my skill! Args: {args}"
```

---

## Creating Your Own Plugin

Plugins add `/slash` commands:

1. Copy `plugins/_template/` to `plugins/my_plugin/`
2. Edit `plugin.json` — set name, description, commands list
3. Edit `plugin.py` — add functions, register in `COMMANDS = {}`
4. Restart MiniClaw

```python
def mycommand(args: str) -> str:
    return f"Result: {args}"

COMMANDS = {"mycommand": mycommand}
```

---

## Memory System

MiniClaw remembers facts across conversations.

**Automatic:** Tell the assistant anything:
> "Remember that my name is Dave"

The agent stores `[REMEMBER: my name is Dave]` in `memory/memory.json` and uses it in future context.

**Manual facts via `/memory`** — view all stored facts.

Notes are stored separately in `memory/notes.json`.

---

## Performance Tips (ThinkCentre M910q)

The M910q with i5-7500T and 16 GB RAM handles `qwen2.5:1.5b` comfortably:

- **Response time:** ~5–15s per message (CPU only, no GPU)
- **RAM usage:** ~2–3 GB for model + server
- **`low_memory_mode: true`** in config limits history to 20 messages
- **`max_tokens: 1024`** keeps responses fast
- **`context_window: 4096`** is optimal for this hardware

If responses feel slow, reduce `max_tokens` to 512 in `miniclaw.json`.

---

## Project Structure

```
miniclaw/
├── miniclaw.json         ← main config (edit this)
├── agent.py              ← core engine (CLI entrypoint)
├── server.py             ← web UI server
├── setup.sh              ← install script
├── README.md
├── memory/
│   ├── memory.json       ← conversation + facts
│   └── notes.json        ← notes skill data
├── logs/
│   └── miniclaw.log
├── skills/
│   ├── weather/          ← wttr.in weather
│   ├── shell/            ← safe shell commands
│   ├── notes/            ← personal notes
│   └── _template/        ← copy this to make a skill
└── plugins/
    ├── calculator/        ← /calc command
    ├── timer/             ← /timer command
    └── _template/         ← copy this to make a plugin
```

---

## Differences from OpenClaw

| OpenClaw | MiniClaw |
|---|---|
| Claude / GPT / cloud models | Ollama local models only |
| Node.js / TypeScript | Python 3 (zero dependencies) |
| WhatsApp, Telegram, Discord | Web UI + CLI only |
| macOS companion app | Browser-based UI |
| ClawHub skill registry | Local skills folder |
| Multi-agent, cron, webhooks | Single agent, manual triggers |
| ~360k GitHub stars 😅 | Just yours 🦀 |

Config format is kept intentionally close to OpenClaw's `miniclaw.json` structure so skills and the mental model translate easily.

---

## License

MIT — do whatever you want with it. 🦀
